# System Rezerwacji Wizyt z Dwustronną Synchronizacją Google Calendar & Zarządzaniem Wizytą

Kompleksowa architektura systemu rezerwacji dla salonu **Fryzjer Polski — Lewko Grzegorz**, integrująca realne terminy z Kalendarza Google salonu w czasie rzeczywistym oraz umożliwiająca klientom bezproblemowe anulowanie lub zmianę terminu za pomocą unikalnego linku.

## User Review & Critical Decisions

> [!IMPORTANT]
> Na podstawie odpowiedzi w trybie planowania potwierdzono dwa kluczowe fundamenty działania:
> 1. **Zarządzanie terminami przez salon**: Dwustronna synchronizacja z Kalendarzem Google (Google Calendar API). Fryzjer widzi każdą wizytę w telefonie, a zajęte terminy automatycznie znikają ze strony.
> 2. **Odwoływanie wizyt przez klienta**: Unikalny link wygenerowany po rezerwacji (np. `/#wizyta?id=...&token=...`) z bezpiecznym widokiem szczegółów i przyciskiem anulowania/przełożenia terminu.

- **Potwierdzona decyzja 1 (Google Calendar)**: Użycie oficjalnego Google Calendar API (zakresy `calendar.events`) z jednorazowym podłączeniem konta Google salonu.
- **Potwierdzona decyzja 2 (Anulowanie przez klienta)**: Po zapisie klient otrzymuje natychmiastowe potwierdzenie z linkiem do zarządzania wizytą. Kliknięcie „Odwołaj wizytę” zwalnia termin w kalendarzu i aktualizuje status w systemie.
- **Rekomendacja architektoniczna (Bez wymuszania logowania od klienta)**: Klient rezerwuje wizytę podając wyłącznie imię, numer telefonu i opcjonalnie e-mail (bez konieczności posiadania konta Google ani rejestracji). Tylko recepcja / administrator salonu łączy kalendarz Google.

---

## 1. Overview & Core Concept

### Co system rozwiązuje
W tradycyjnym modelu fryzjerzy musieliby przepisywać rezerwacje ze strony do zeszytu lub zewnętrznych aplikacji. Dzięki dwustronnej synchronizacji:
1. **Dla klienta**: Widzi wyłącznie faktycznie wolne godziny fryzjera. Po zapisaniu dostaje natychmiastowe potwierdzenie i unikalny link do ewentualnego odwołania wizyty bez konieczności dzwonienia.
2. **Dla fryzjera / salonu**: Każda wizyta pojawia się natychmiast w kalendarzu Google na telefonie fryzjera z powiadomieniem (kto, jaka usługa, telefon klienta). Jeśli fryzjer zablokuje termin w telefonie (np. przerwa, urlop), strona natychmiast przestaje oferować ten slot.

---

## 2. User Experience & Visual Design

### Ścieżka klienta (Flow Rezerwacji)
1. **Wybór usługi i fryzjera**: Klient wybiera mistrza (np. Grzegorz Lewko, Piotr, Stasia, Olga) oraz usługę z cennika (np. Strzyżenie męskie, Combo, Broda).
2. **Dynamiczny kalendarz wolnych terminów**: Aplikacja pobiera zajęte okna z Google Calendar dla wybranego dnia i renderuje wyłącznie wolne godziny (z zachowaniem kwadratowej estetyki `rounded-none`).
3. **Potwierdzenie danych**: Klient wprowadza imię oraz numer telefonu (format `+48`).
4. **Ekran sukcesu z linkiem do zarządzania**: Wyświetla się numer rezerwacji, dokładny adres (Karmelicka 25) oraz **przycisk „Zarządzaj swoją wizytą” / link do skopiowania**.
5. **Panel zarządzania wizytą (Widok Klienta)**:
   - Dostępny przez URL z tokenem (np. `#wizyta?id=FP-839201&token=sec_abc123`).
   - Pokazuje: status („Potwierdzona”, „Zakończona”, „Anulowana”), datę, godzinę, fryzjera i wybraną usługę.
   - Akcje: **„Odwołaj wizytę”** (z prośbą o potwierdzenie) oraz opcję **„Zmień termin”**.
   - Po odwołaniu: Wydarzenie z Kalendarza Google zostaje usunięte lub oznaczone jako [ANULOWANE], a godzina natychmiast wraca do puli dostępnych slotów na stronie.

### Wizualna spójność i stylistyka
- Pełna spójność z istniejącą, ostrą estetyką salonu: kwadratowe kafle (`rounded-none`), złote akcenty (`#d4af37`), czarne tło i czyste typograficzne etykiety bez zbędnych kapsułek czy animowanych ozdobników.
- Jasne stany ładowania (spinner pobierania terminów z kalendarza) i natychmiastowy feedback.

---

## 3. Key Product Decisions & Trade-Offs

### Decyzja 1: Pobieranie wolnych slotów (FreeBusy / Events API)
- **Wybrane rozwiązanie**: Zapytanie do Google Calendar API o zajęte okna czasowe w wybranym przedziale (np. 8:00–19:00 w dni robocze) i odejmowanie ich od godzin pracy salonu.
- **Dlaczego**: Eliminuje ryzyko double-bookingu (nakładania się klientów).
- **Alternatywa odrzucona**: Sztywne godziny wpisane w kodzie (które powodowałyby konflikty z wizytami umawianymi telefonicznie w salonie).

### Decyzja 2: Przechowywanie danych rezerwacji i obsługa tokenu anulowania
- **Wybrane rozwiązanie**: Bezpieczny rekord wizyty (z ID wydarzenia w Google Calendar `calendarEventId`, danymi klienta i kryptograficznym tokenem dostępu).
- **Dlaczego**: Klient nie musi logować się kontem Google ani zakładać konta w salonie – wystarczy mu dedykowany link do jego konkretnej wizyty.

---

## 4. Technical Architecture & Data Strategy

### Diagram Przepływu Danych

```
┌────────────────────────────────────────────────────────────────────────┐
│                          KLIENT W PRZEGLĄDARCE                         │
│  - Wybór fryzjera i usługi                                            │
│  - Pobranie wolnych godzin                                             │
│  - Wysłanie rezerwacji (Imię, Telefon)                                 │
└──────────────────┬─────────────────────────────────▲───────────────────┘
                   │ 1. POST / rezerwacja            │ 4. Link i token
                   ▼                                 │    potwierdzenia
┌────────────────────────────────────────────────────┴───────────────────┐
│                      SERWIS REZERWACJI (App Engine)                    │
│  - Walidacja danych (czas trwania usługi, godziny pracy salonu)         │
│  - Wygenerowanie unikalnego kodu FP-XXXXXX oraz tokenu anulowania      │
└──────────────────┬─────────────────────────────────┬───────────────────┘
                   │ 2. Utworzenie wydarzenia        │ 3. Zapis statusu
                   ▼                                 ▼
┌──────────────────────────────────────┐  ┌──────────────────────────────┐
│        GOOGLE CALENDAR API           │  │   LOKALNA / CHMUROWA BAZA    │
│  - Dodanie wydarzenia w kalendarzu   │  │   - id, token, telefon, data │
│  - Powiadomienie na telefon fryzjera │  │   - status: 'confirmed'      │
│  - Usunięcie przy anulowaniu         │  │             'cancelled'      │
└──────────────────────────────────────┘  └──────────────────────────────┘
```

### Struktura Obiektu Rezerwacji
```typescript
interface BookingRecord {
  id: string; // np. "FP-849201"
  cancellationSecret: string; // unikalny bezpieczny token do anulowania
  serviceId: string;
  serviceName: string;
  barberId: string;
  barberName: string;
  dateStr: string; // "2026-10-30"
  time: string; // "14:00"
  durationMinutes: number;
  clientName: string;
  clientPhone: string;
  clientEmail?: string;
  clientNotes?: string;
  googleCalendarEventId?: string;
  status: 'confirmed' | 'cancelled' | 'rescheduled';
  createdAt: string;
}
```

### Punkty Wdrożenia Krok Po Kroku (do realizacji po zatwierdzeniu)
1. **Google Workspace OAuth**: Uruchomienie narzędzia `set_up_oauth` dla zakresu `https://www.googleapis.com/auth/calendar.events` (umożliwia tworzenie, odczyt i usuwanie wydarzeń w kalendarzu fryzjera).
2. **Serwis Google Calendar (`src/services/calendarService.ts`)**:
   - `fetchAvailableSlots(barberId, date)`: Wyliczanie wolnych okien na podstawie zajętości w kalendarzu.
   - `createBookingEvent(booking)`: Tworzenie wydarzenia z tytułem `[FP] {Usługa} - {Klient} ({Telefon})` i przypisaniem do kalendarza.
   - `cancelBookingEvent(eventId)`: Usunięcie lub aktualizacja wydarzenia w Google Calendar.
3. **Widok Klienta do Zarządzania Wizytą (`src/components/BookingManagementModal.tsx` / strona `#wizyta`)**:
   - Wyświetlenie szczegółów na podstawie `id` i `token`.
   - Przycisk z potwierdzeniem: „Czy na pewno chcesz odwołać wizytę?”.
   - Komunikat o zwolnieniu terminu i potwierdzenie anulowania.
4. **Powiadomienie i przejście w sekcji głównej**: Po zarezerwowaniu w `BookingCalendarSection` klient od razu otrzymuje wygenerowany link z możliwością skopiowania i natychmiastowego sprawdzenia.
